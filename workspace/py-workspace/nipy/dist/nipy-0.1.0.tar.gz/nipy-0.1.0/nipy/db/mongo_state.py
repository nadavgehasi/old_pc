from pymongo import MongoClient
from hashlib import sha256


def read_state(unit):
    with MongoClient('localhost', 27017) as client:
        db = client.nipy_db
        state_collection = db.state_collection
        return state_collection.find_one({"id": sha256(unit.encode())})


def write_state(unit):
    pass
