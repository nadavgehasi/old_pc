# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nipy', 'nipy.core', 'nipy.db', 'nipy.queues', 'nipy.utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'nipy',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'ng',
    'author_email': 'nadavgehasi@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
